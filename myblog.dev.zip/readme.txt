Install:
1. Upload files from git
2. Create db with dump blog.sql
3. Edit /config/config_db.php
4. It's all.