<?php
define('NAME_BLOG', 'My Public Blog');
define('TITLE_COMMENTS', 'Comments');
define('DEF_COMMENT', 'Your comment will be first');
define('DEF_POST', 'Your post will be first');
define('SLIDER_LIMIT', 5);
?>